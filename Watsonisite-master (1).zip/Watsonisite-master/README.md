# Watsonisite- Information about Crypto Site

## Demo
#### Here is a working live demo :  https://watsonisite.netlify.app/

## Built with 

- [React JS](https://reactjs.org/)
- [Material UI](https://v4.mui.com/)
- [Chart JS](https://reactchartjs.github.io/react-chartjs-2/#/)
