const firebaseConfig = {
    apiKey: "AIzaSyBF1zYaDhp34yzHWoEkmfdos3ofFwzOxKY",
    authDomain: "watsonisite.firebaseapp.com",
    projectId: "watsonisite",
    storageBucket: "watsonisite.appspot.com",
    messagingSenderId: "46368785155",
    appId: "1:46368785155:web:8133f2a664a03c5f251f36"
  };
  
  export default firebaseConfig;